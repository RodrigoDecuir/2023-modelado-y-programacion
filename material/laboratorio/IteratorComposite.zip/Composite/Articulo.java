public interface Articulo{
	public String mostrarInformacion();
	public double mostrarPrecio();
}