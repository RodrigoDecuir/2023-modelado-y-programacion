public interface EstadoRobot{
	public void activar();
	public void caminar();
	public void demoler();
	public void recolectar();
	public void apagarse();
}