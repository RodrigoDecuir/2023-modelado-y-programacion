/**
 * Clase para implementar a Dittuu.
 */
public class Dittuu {
    private String nombreAtaque;
    private int puntosAtaque;
    private DittuuAtaque dittuu;

    public Dittuu() {
    
    }

 //   public ataque(String nombreAtaque, int puntosAtaque) {
        
  //  }

    public void atacar(Personaje enemigo) {
     
    }
    
    public int defender() {

    }
    public String tipo() {

    }

    public String toString() {

    }
}
