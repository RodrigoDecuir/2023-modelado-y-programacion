public interface DittuuAtaque {
    public String nombreAtaque();
    public String obtenerDescripcion();
    public void atacar(Personaje enemigo);
    public int defender();
}
