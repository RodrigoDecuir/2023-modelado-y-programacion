public class Korby {
    private String nombreAtaque;
    private int puntosAtaque;
    private KorbyAtaque korby;
    
    public Korby() {

    }

//    public KorbyAtaque() {
        
 //   }

//    public ataque(String nombreAtaque, int puntosAtaque) {
        
  //  }

    public void atacar(Personaje enemigo) {
        
    }
    
    public int defender() {

    }

    public String tipo() {
        
    }

    public String toString() {

    }
}
