public class MeganMan {    
    private String nombreAtaque;
    private int puntosAtaque;
    private MeganManAtaque meganMan;

    public MeganMan();

//    public ataque(String nombreAtaque, int puntosAtaque) {
    
//    }

    public void atacar(Personaje enemigo) {
    
    }
    
    public int defender() {

    }

    public String tipo() {
    
    }

    public String toString() {

    }
}
