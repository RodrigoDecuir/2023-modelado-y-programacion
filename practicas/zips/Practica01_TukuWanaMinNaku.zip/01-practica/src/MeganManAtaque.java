public interface MeganManAtaque {
    public String nombreAtaque();
    public String obtenerDescripcion();
    public void ataque(Personaje enemigo);
    public int defender();
}
