public class Personaje {
    private String nombreAtaque;
    private int puntosAtaque;
    
    public Personaje() {

    }
    
    public String ataque(String nombreAtaque, int puntosAtaque){

    }
    
    public void atacar(Personaje enemigo) {

    }
    
    public int defender() {

    }
    
    public String tipo() {
     
    }
    
    public String estaVivo() {
    
    }
    
    public string toString() {

    }
}
